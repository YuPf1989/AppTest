package com.rain.apptest

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.rain.apptest.ui.recycler.RecyclerTestActivity
import kotlinx.android.synthetic.main.activity_main.*

/**
 * 主要是各种功能的测试
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_recycler.setOnClickListener {
            startActivity(Intent(this,RecyclerTestActivity::class.java))
        }
    }
}


