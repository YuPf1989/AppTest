package com.rain.apptest.ui.recycler

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import com.rain.apptest.R

class RecyclerTestActivity:AppCompatActivity() {

    private val recyclerFragment:RecyclerFragment by lazy {
        RecyclerFragment.getInstance()
    }

    private val nestedFragment by lazy {
        NestedFragment.getInstance()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_recycler)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.recycler_menu,menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            // 复用
            R.id.action_recycle->{
                showFragment(recyclerFragment)
            }

            // 与NestedScrollView的滑动冲突
            R.id.action_nested1->{
                showFragment(nestedFragment)
            }


        }
        return super.onOptionsItemSelected(item)
    }

    fun showFragment(f:Fragment){
        val t = supportFragmentManager.beginTransaction()
        t.replace(R.id.container,f)
            .setCustomAnimations(R.anim.fade_in,R.anim.fade_out)
            .commitAllowingStateLoss()
    }
}